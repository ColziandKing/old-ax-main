# Citystates_Plus
This adds more City States to your Unciv gameplay but removes some civs like Celts and Korea.
