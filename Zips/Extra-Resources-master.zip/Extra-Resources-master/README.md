# NOTE
- This mod has been abandoned and canceled in favor of a future mod that I will make (sooner or later), improving upon what I have done in this mod. 
- I have decided to abandon this mod since I cannot bother myself to update this for the latest versions of Unciv, considering that a lot of features in this mod has been made obsolete by other well-made mods such as RekMOD.
- Despite all of these reasons, this mod will not be deleted and will still be found here, just for posterity. Thank you for your appreciation.

## Changelog for v1.6.3
- Changed the Camel Bowman and the Heavy Camel Bowman units to Ranged.

NOTE: Requires the latest version of the [Civ 5 Expansion Mod](https://github.com/k4zoo/Civ5ExpansionMod) by Red11/k4zoo

A mod for Unciv that adds 58 resources, 7 new units, 2 new improvements, and 8 buildings. From the highest peaks to the lowest trenches, this mod will help make your game more interesting and realistic.

## Roadmap
- Pixel art
- New units! (Drones, robots, etc.)

Help is greatly appreciated. You could contact me on Discord (Cavenir#6636), or you could reach out using the links provided on [my website](https://secession-cycles.carrd.co). Thank you.
