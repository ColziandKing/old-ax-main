# Formerly MCEnchantments
Adds & replaces promotions to Minecraft Enchantments
